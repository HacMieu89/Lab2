﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Tulpep.NotificationWindow;
using System.Runtime.InteropServices;


namespace lab2._4
{
    public partial class Service1 : ServiceBase
    {
        Timer timer = new Timer();
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            WriteToFile("Service is started at " + DateTime.Now);
            timer.Elapsed += new ElapsedEventHandler(showpopup);
            timer.Interval = 5000; //number in milisecinds
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
            WriteToFile("Service is stopped at " + DateTime.Now);
        }
        private void showpopup(object source, ElapsedEventArgs e)
        {
            EventLog log = new EventLog();
            log.Log = "Security";
            
            foreach(EventLogEntry entry in log.Entries)
            {
                if(entry.EventID==4624 || entry.EventID==4672)
                {
                    if (DateTime.Now.Day == entry.TimeGenerated.Day && DateTime.Now.Month == entry.TimeGenerated.Month&&
                        DateTime.Now.Year == entry.TimeGenerated.Year&& DateTime.Now.Hour == entry.TimeGenerated.Hour)
                    {
                        int timenow = DateTime.Now.Minute * 60 + DateTime.Now.Second;
                        int timeevent = entry.TimeGenerated.Minute * 60 + entry.TimeGenerated.Second;
                       
                        if ((timenow - timeevent) < 9)
                        {
                            WriteToFile("show popup at " + DateTime.Now);
                            PopupNotifier popup = new PopupNotifier();
                            popup.TitleText = "Hello";
                            popup.ContentText= "18520532 && 18521544";
                            popup.Popup();
                            
                            break;
                        }
                    }
                }
                
            }

            
            Process DProcess = new Process();
            string command = "msg * hello";

            System.Diagnostics.Process.Start("CMD.exe", command);
        }
        //
        public void WriteToFile(string Message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = AppDomain.CurrentDomain.BaseDirectory +
           "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') +
           ".txt";
            if (!File.Exists(filepath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
        }
    }
}
